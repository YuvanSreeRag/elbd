package com.example.dell.elbd;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * Created by sreerag on 2/4/18.
 */

public class Tab2Notification extends Fragment {
    private OnFragmentInteractionListener mListener;
    public String sec, l1, l2;
    ListView listView;
    FirebaseDatabase database;
    DatabaseReference ref;
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    Consumer cons ;

    NotificationCompat.Builder notification;
    private static final int uniqueID =4516;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab2_notification, container, false);

        cons = new Consumer();
        listView = rootView.findViewById(R.id.lview);
        notification =new NotificationCompat.Builder(getContext());
        notification.setAutoCancel(true);



        getdata();

//        TextView s=(TextView)(rootView.findViewById(R.id.textView9));
//        sec = getActivity().getIntent().getStringExtra("section");
  //      s.setText("Consumer List of Section : "+sec);
        return rootView;
    }


    private interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
    void getdata(){database = FirebaseDatabase.getInstance();
        ref = database.getReference("Post");
        list = new ArrayList<>();

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterator<DataSnapshot> dataSnapshots = dataSnapshot.getChildren().iterator();
                while (dataSnapshots.hasNext()) {
                    DataSnapshot dataSnapshotChild = dataSnapshots.next();
                    if (dataSnapshotChild.child("Break").getValue().toString().equals("true")) {
                    notif();
                    l1 = dataSnapshotChild.child("Location").child("lat").getValue().toString();
                    l2 = dataSnapshotChild.child("Location").child("long").getValue().toString();
                    StringBuffer s=new StringBuffer();
                    s.append("Post No           : "+dataSnapshotChild.getKey()+"\n");
                    s.append("Break               : "+dataSnapshotChild.child("Break").getValue()+"\n");
                    s.append("Latitude           : "+dataSnapshotChild.child("Location").child("lat").getValue()+"\n");
                    s.append("Longitude        : "+dataSnapshotChild.child("Location").child("long").getValue()+"\n");





                    Log.e("check", dataSnapshotChild.getKey().toString());
                    list.add(s.toString());
                    Log.e("check", list.get(list.size() - 1));
                     }
                }
                createlist();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    void createlist() {
        Log.e("size", list.size() + "");
        String[] lis = new String[list.size()];
        lis = list.toArray(lis);
        adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, lis);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {


                Intent intent = new Intent("com.example.dell.elbd.MapsActivity");
                intent.putExtra("latitude", l1);
                intent.putExtra("longitude", l2);
                startActivity(intent);
                //String item = ((TextView)view).getText().toString();

                //Toast.makeText(getBaseContext(), item, Toast.LENGTH_LONG).show();

            }
        });
    }


    public void notif(){
        notification.setSmallIcon(R.drawable.elbd);
        notification.setTicker("This is the ticke");
        notification.setWhen(System.currentTimeMillis());
        notification.setContentTitle("Line Broken");
        notification.setContentText("Tap to see location");
        notification.setVibrate(new long[] { 1000, 1000, 1000, 1000, 1000 });
        notification.setLights(Color.WHITE,3000,3000);

        Intent intent =new Intent("com.example.dell.elbd.Tabbed");
        PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0 , intent, PendingIntent.FLAG_UPDATE_CURRENT);
        notification.setContentIntent(pendingIntent);

        NotificationManager nm = (NotificationManager) getActivity().getSystemService(NOTIFICATION_SERVICE);
        nm.notify(uniqueID, notification.build());

    }




}





