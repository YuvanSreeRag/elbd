package com.example.dell.elbd;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper myDb;
    static String section;
    private static EditText consumer_no;
    private static EditText ph_no;
    private static Button login_button;
    private static Button next;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        consumer_no = (EditText)findViewById(R.id.editText_consno);
        ph_no = (EditText)findViewById(R.id.editText_phno);
        login_button = (Button)findViewById(R.id.button_login);

        //myDb = new DatabaseHelper(this);
        Next();

    }

    public void LoginButton(View v) {
        // Write a message to the database

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference("Consumer");
        //myRef.child("mrng").setValue("Hello, World!");

        //static String section;
        Consumer cons = new Consumer(consumer_no.getText().toString(), ph_no.getText().toString(),"sad");
        //userupload(cons);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild(consumer_no.getText().toString())) {
                    if (dataSnapshot.child(consumer_no.getText().toString()).child("phno").getValue().toString().equals(ph_no.getText().toString()))
                    {
                        section=dataSnapshot.child(consumer_no.getText().toString()).child("section").getValue().toString();
                        //st=true;
                        //Consumer c=dataSnapshot.child(consumer_no.getText().toString()).getValue(Consumer.class);
                        Intent intent = new Intent("com.example.dell.elbd.Home");
                        intent.putExtra("no", consumer_no.getText().toString());
//                      intent.putExtra("name", c.name);
//                      intent.putExtra("section", c.section);
//                      intent.putExtra("phn", c.phno);
                        intent.putExtra("name",dataSnapshot.child(consumer_no.getText().toString()).child("name").getValue().toString());
                        intent.putExtra("section", section);
                        intent.putExtra("phn",dataSnapshot.child(consumer_no.getText().toString()).child("phno").getValue().toString());
                        intent.putExtra("previous",dataSnapshot.child(consumer_no.getText().toString()).child("prev").getValue().toString());
                        intent.putExtra("current",dataSnapshot.child(consumer_no.getText().toString()).child("curr").getValue().toString());
                        Log.d("ssd","asdasdasd");
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(MainActivity.this, "Incorrect mobile number", Toast.LENGTH_SHORT).show();
                }

                else {
                    Toast.makeText(MainActivity.this, "Incorrect consumer number or mobile number", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
/*if(st){
    intent.putExtra("section", section);
    Log.d("ssd","asdasdasd");

else {


    Toast.makeText(Login.this, "Incorrect consumer_no or ph_no", Toast.LENGTH_SHORT).show();
}*/

    }

    public void Next()
    {
        next = (Button)findViewById(R.id.button_next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent("com.example.dell.elbd.Login");
                startActivity(intent);
            }
        });

    }
}
