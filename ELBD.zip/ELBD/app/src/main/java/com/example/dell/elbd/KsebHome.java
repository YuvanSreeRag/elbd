package com.example.dell.elbd;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class KsebHome extends AppCompatActivity {
    //public String sec;
    ListView listView;
    FirebaseDatabase database;
    DatabaseReference ref;
    ArrayList<String> list;
    ArrayAdapter <String> adapter;
    Consumer cons ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kseb_home);

        cons = new Consumer();
        listView = findViewById(R.id.listView);
        database = FirebaseDatabase.getInstance();
        ref = database.getReference("Consumer");
        list = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, R.layout.cons_info, R.id.consInfo, list);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren())
                {

                    cons = ds.getValue(Consumer.class);
                    list.add(cons.getName().toString() + "  "+cons.getPrev().toString() + "  "+cons.getCurr().toString());
                }
                listView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    //    populate();
    //    TextView s=(TextView)(findViewById(R.id.textView9));
    //    sec = getIntent().getStringExtra("section");
    //    s.setText(sec);
    }
/*    public void populate() {
        db=new DB_product(getActivity());
        c=db.get_all();
        if(c.getCount()!=0)
        {
            List<String> product=new ArrayList<>();
            StringBuffer sb = new StringBuffer();
            while (c.moveToNext())
            {
                sb.delete(0,sb.length());
                sb.append("\nProduct Name           : " + c.getString(0) +
                        "\nPurchased On           : " + c.getString(1) + "\n");
                sb.append(  "Warranty Expires On: " + c.getString(2) +
                        "\nService Details         : " + c.getString(3) + "\n");
                sb.append(  "Stored Location     : " + c.getString(4));
                product.add(sb.toString());
            }
*/
}
