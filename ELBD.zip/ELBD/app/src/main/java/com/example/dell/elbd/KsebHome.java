package com.example.dell.elbd;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class KsebHome extends AppCompatActivity {
    public String sec;
    ListView listView;
    FirebaseDatabase database;
    DatabaseReference ref;
    ArrayList<String> list;
    ArrayAdapter <String> adapter;
    Consumer cons ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kseb_home);

        cons = new Consumer();
        listView = findViewById(R.id.listView);
        getdata();

    //    populate();
        TextView s=(TextView)(findViewById(R.id.textView9));
        sec = getIntent().getStringExtra("section");
        s.setText("Consumer List of Section : "+sec);

    }
    void getdata(){database = FirebaseDatabase.getInstance();
        ref = database.getReference("Consumer");
        list = new ArrayList<>();

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterator<DataSnapshot> dataSnapshots = dataSnapshot.getChildren().iterator();
                 while (dataSnapshots.hasNext()) {
                    DataSnapshot dataSnapshotChild = dataSnapshots.next();
                                //if (dataSnapshotChild.child("section").getValue().toString().equals(sec)) {

                                StringBuffer s=new StringBuffer();
                                s.append("Consumer No : "+dataSnapshotChild.getKey()+"\n");
                                s.append("Name               : "+dataSnapshotChild.child("name").getValue()+"\n");
                                s.append("Previous          : "+dataSnapshotChild.child("prev").getValue()+"\n");
                                s.append("Current            : "+dataSnapshotChild.child("curr").getValue()+"\n");

                                    Log.e("check", dataSnapshotChild.getKey().toString());
                                    list.add(s.toString());
                                    Log.e("check", list.get(list.size() - 1));
                               // }
                }
                createlist();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
/*    public void populate() {
        db=new DB_product(getActivity());
        c=db.get_all();
        if(c.getCount()!=0)
        {
            List<String> product=new ArrayList<>();
            StringBuffer sb = new StringBuffer();
            while (c.moveToNext())
            {
                sb.delete(0,sb.length());
                sb.append("\nProduct Name           : " + c.getString(0) +
                        "\nPurchased On           : " + c.getString(1) + "\n");
                sb.append(  "Warranty Expires On: " + c.getString(2) +
                        "\nService Details         : " + c.getString(3) + "\n");
                sb.append(  "Stored Location     : " + c.getString(4));
                product.add(sb.toString());
            }
*/

void createlist()
{
    Log.e("size",list.size()+"");
    String[] lis = new String[list.size()];
    lis=list.toArray(lis);
    adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lis);
    listView.setAdapter(adapter);
}
}
