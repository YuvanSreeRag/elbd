package com.example.dell.elbd;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Home extends AppCompatActivity {
    public boolean s = true;
    public String a,b,c,d,e,f;
    float unit,price;
    SharedPreferences mPreferences;
    SharedPreferences.Editor editor;
    Context _context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mPreferences = getApplicationContext().getSharedPreferences("MyPref", 0);

        TextView cno=(TextView)(findViewById(R.id.cons_no));
        TextView cname=(TextView)(findViewById(R.id.cons_name));
        TextView sec=(TextView)(findViewById(R.id.section));
        TextView ph=(TextView)(findViewById(R.id.phone));
        TextView pr=(TextView)(findViewById(R.id.prev));
        TextView cu=(TextView)(findViewById(R.id.curr));
        TextView un=(TextView)(findViewById(R.id.units));
        TextView ch=(TextView)(findViewById(R.id.charge));
        // Read from the database
        a = mPreferences.getString("no",null);
        b = mPreferences.getString("name",null);
        c = mPreferences.getString("section",null);
        d = mPreferences.getString("phn",null);
        e = mPreferences.getString("previous",null);
        f = mPreferences.getString("current",null);
        cno.setText(a);
        cname.setText(b);
        sec.setText(c);
        ph.setText(d);
        pr.setText(e);
        cu.setText(f);
        unit = (float) (Integer.parseInt(f)- Integer.parseInt(e));
        un.setText(Float.toString(unit));
        unit /= 2;
        if (unit<=50)
            price = (float) (unit * 2.9);
        else if (unit>=51 && unit<=100)
            price = (float) (145 + (unit-50)*3.4);
        else if (unit>=101 && unit<=150)
            price = (float) (315 + (unit-100)*4.5);
        else if (unit>=151 && unit<=200)
            price = (float) (540 + (unit-150)*6.1);
        else if (unit>=201 && unit<=250)
            price = (float) (845 + (unit-200)*7.3);
        else if (unit>=251 && unit<=300)
            price = (float) (unit*5.5);
        else if (unit>=301 && unit<=350)
            price = (float) (unit*6.2);
        else if (unit>=351 && unit<=400)
            price = (float) (unit*6.5);
        else if (unit>=401 && unit<=500)
            price = (float) (unit*6.7);
        else if (unit>=501)
            price = (float) (unit*7.5);

        price *=2;
        ch.setText(Float.toString(price));
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
               // Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                //Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tabbed, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            editor.clear();
            editor.commit();

            // After logout redirect user to Loing Activity
            Intent intent = new Intent(_context, MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
