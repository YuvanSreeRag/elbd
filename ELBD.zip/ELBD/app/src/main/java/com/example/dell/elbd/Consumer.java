package com.example.dell.elbd;

import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by punnyq on 8/3/18.
 */

public class Consumer {

    public String name;
    public String phno;
    public String section;

    public Consumer() {
    }

    public Consumer(String msg, String sender, String number) {
        this.name = msg;
        this.phno = sender;
        this.section = number;
    }

}


