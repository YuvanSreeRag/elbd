package com.example.dell.elbd;

import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by punnyq on 8/3/18.
 */

public class Consumer {

    public String name;
    public String prev;
    public String curr;

    public Consumer() {
    }

    public Consumer(String name, String prev, String curr) {
        this.name = name;
        this.prev = prev;
        this.curr = curr;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrev() {
        return prev;
    }

    public void setPrev(String prev) {
        this.prev = prev;
    }

    public String getCurr() {
        return curr;
    }

    public void setCurr(String curr) {
        this.curr = curr;
    }

    /*   public Consumer(String msg, String sender, String number) {
        this.name = msg;
        this.phno = sender;
        this.section = number;
    }
*/
}


