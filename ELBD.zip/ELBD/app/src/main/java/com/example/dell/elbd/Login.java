package com.example.dell.elbd;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {
    //private FirebaseAuth mAuth;
    DatabaseReference myRef;
    static boolean st=false;
    static String section;
    SharedPreferences mPreferences;
    private static EditText username;
    private static EditText password;
    private static Button kseb_login_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        KsebLoginButton();

    }



    public void KsebLoginButton() {
        username = (EditText) findViewById(R.id.editText_user);
        password = (EditText) findViewById(R.id.editText_pass);
        kseb_login_button = (Button) findViewById(R.id.button_kseb_login);

        kseb_login_button.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        final DatabaseReference myRef = database.getReference("Kseb");
                        myRef.addListenerForSingleValueEvent(new
                            ValueEventListener() {
                            @Override
                            public void onDataChange (DataSnapshot dataSnapshot){
                                if (dataSnapshot.hasChild(username.getText().toString())) {
                                    if (dataSnapshot.child(username.getText().toString()).child("pass").getValue().toString().equals(password.getText().toString())) {
                                        section = dataSnapshot.child(username.getText().toString()).child("section").getValue().toString();
                                        Intent intent = new Intent("com.example.dell.elbd.Tabbed");
                                        intent.putExtra("section", section);
                                        Log.d("ssd", "asdasdasd");
                                        startActivity(intent);
                                    } else
                                        Toast.makeText(Login.this, "Incorrect username", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(Login.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
                                }
                            }
                                @Override
                                public void onCancelled (DatabaseError databaseError){

                                }
                            });
                    }
                });
    }


    public void userupload(Consumer c)
    {
        //Log.e("firebase",firebaseUser.toString());
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            myRef = database.getReference("Consumer");
            //Toast.makeText(getApplicationContext(), firebaseUser.getEmail(), Toast.LENGTH_SHORT).show();
           myRef.child("123").setValue(c);

    }

}

